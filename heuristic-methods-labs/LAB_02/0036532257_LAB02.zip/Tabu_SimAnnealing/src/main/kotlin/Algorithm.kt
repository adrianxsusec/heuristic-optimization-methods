import kotlin.math.abs
import kotlin.math.exp

interface Algorithm {
    fun compute(maxIter: Int, instancePath: String, instanceNumber: Number): Pair<List<Player>, List<Player>>
    fun singleSwapNeighborhood(
        firstTeam: List<Player>,
        subs: List<Player>,
        allPlayers: List<Player>,
        constraints: Constraints,
    ): List<Triple<List<Player>, List<Player>, Player>> {
        val neighbors = mutableListOf<Triple<List<Player>, List<Player>, Player>>()
        val playersSortedByPoints = allPlayers.sortedByDescending { it.points }

        for (player in firstTeam) {
            for (i in 0..10) {
                val playersSamePosition = playersSortedByPoints.filter { it.position == player.position }
                val newFirstTeam = firstTeam.toMutableList()

                if (playersSamePosition[i] in newFirstTeam) {
                    continue
                }

                newFirstTeam.remove(player)
                newFirstTeam.add(playersSamePosition[i])

                if (generalConstraintsSatisfied(newFirstTeam, subs, constraints.deepCopy())) {
                    neighbors.add(Triple(newFirstTeam, subs, playersSamePosition[i]))
                }
            }
        }
        return neighbors
    }
}

class Greedy(
    private val rclAlpha: Double,
    private val constraints: Constraints,
    private val players: List<Player>
) : Algorithm {
    override fun compute(maxIter: Int, instancePath: String, instanceNumber: Number): Pair<List<Player>, List<Player>> {
        val localConstraints = constraints.deepCopy()

        val firstTeam = selectFirstTeam(localConstraints, players)
        val subs = selectSubs(firstTeam, localConstraints, players)

        return Pair(firstTeam, subs)
    }

    private fun selectFirstTeam(localConstraints: Constraints, players: List<Player>): List<Player> {
        val firstTeam = mutableListOf<Player>()
        val playersDescendingFitness = players.sortedByDescending { it.pointsPerPrice }.toMutableList()

        while (firstTeam.size < constraints.numFirstTeamPlayers) {
            val rcl = getMaxRcl(playersDescendingFitness) { it.pointsPerPrice }
            val player = rcl.random()

            if (firstTeamPlayerConstraintsSatisfied(player, localConstraints)) {
                firstTeam.add(player)
                localConstraints.budget -= player.price
                localConstraints.numPerPosition[player.position] =
                    localConstraints.numPerPosition[player.position]!! - 1
                localConstraints.numPerClub[player.club] = localConstraints.numPerClub[player.club]!! - 1
                localConstraints.numFirstTeamPlayers -= 1
                if (player.position == PlayerPosition.GK) {
                    localConstraints.gkInFirstTeam -= 1
                }
                if (player.position == PlayerPosition.DEF) {
                    localConstraints.minDefInFirstTeam -= 1
                }
                if (player.position == PlayerPosition.FW) {
                    localConstraints.minAttInFirstTeam -= 1
                }
            }
            playersDescendingFitness.remove(player)
        }
        return firstTeam
    }

    private fun selectSubs(
        firstTeam: List<Player>,
        localConstraints: Constraints,
        players: List<Player>
    ): List<Player> {
        val subs = mutableListOf<Player>()
        val playersAscendingPrice = players.sortedBy { it.price }.toMutableList()

        while (subs.size < constraints.numSubs) {
            val player = playersAscendingPrice.first()

            if (subsPlayerConstraintsSatisfied(firstTeam, player, localConstraints)) {
                subs.add(player)
                localConstraints.numPerPosition[player.position] =
                    localConstraints.numPerPosition[player.position]!! - 1
                localConstraints.numPerClub[player.club] = localConstraints.numPerClub[player.club]!! - 1
                localConstraints.budget -= player.price
                localConstraints.numSubs -= 1
            }
            playersAscendingPrice.remove(player)
        }

        return subs
    }

    private fun firstTeamPlayerConstraintsSatisfied(player: Player, constraints: Constraints): Boolean {
        if (!generalPlayerConstraintsSatisfied(player, constraints)) {
            return false
        }
        if (player.position == PlayerPosition.GK && constraints.gkInFirstTeam == 0) {
            return false
        }
        if (player.position !== PlayerPosition.FW && constraints.numFirstTeamPlayers <= constraints.minAttInFirstTeam) {
            return false
        }
        if (player.position !== PlayerPosition.DEF && constraints.numFirstTeamPlayers <= constraints.minDefInFirstTeam) {
            return false
        }
        return true
    }

    private fun subsPlayerConstraintsSatisfied(
        firstTeam: List<Player>,
        player: Player,
        constraints: Constraints
    ): Boolean {
        if (!generalPlayerConstraintsSatisfied(player, constraints)) {
            return false
        }
        if (firstTeam.contains(player)) {
            return false
        }
        return true
    }

    private fun generalPlayerConstraintsSatisfied(player: Player, constraints: Constraints): Boolean {
        if (player.price > constraints.budget) {
            return false
        }
        if (constraints.numPerPosition[player.position] == 0) {
            return false
        }
        if (constraints.numPerClub[player.club] == 0) {
            return false
        }
        return true
    }

    private fun getMaxRcl(sortedPlayers: List<Player>, property: (Player) -> Double): List<Player> {
        val threshold =
            property(sortedPlayers.first()) - rclAlpha * (property(sortedPlayers.first()) - property(sortedPlayers.last()))

        return sortedPlayers.filter { property(it) >= threshold }
    }
}

class TabuSearch(
    private val constraints: Constraints,
    private val allPlayers: List<Player>,
    private val selectedTeam: Pair<List<Player>, List<Player>>,
    private val tabuTenure: Int
) : Algorithm {
    override fun compute(maxIter: Int, instancePath: String, instanceNumber: Number): Pair<List<Player>, List<Player>> {
        var solution = selectedTeam
        var bestSolution = selectedTeam

        val tabuList = TabuList<Player>(tabuTenure)

        val bestSolutionThroughTime = mutableListOf<Int>()
        val iterations = mutableListOf<Int>()

        for (i in 0..maxIter) {
            var neighbours = singleSwapNeighborhood(solution.first, solution.second, allPlayers, constraints)
            neighbours = neighbours.filter { !tabuList.contains(it.third) }

            if (neighbours.isEmpty()) {
                continue
            }

            val bestNeighbour = getBestNeighbour(neighbours)
            tabuList.add(bestNeighbour.third)
            solution = Pair(bestNeighbour.first, bestNeighbour.second)

            if (fitness(solution) > fitness(bestSolution)) {
                bestSolution = solution
            }

            bestSolutionThroughTime.add(fitness(bestSolution))
            iterations.add(i)
        }
        printChartsToFile("tabu_performance", instanceNumber, bestSolutionThroughTime, iterations)
        return bestSolution
    }

    private fun fitness(solution: Pair<List<Player>, List<Player>>): Int {
        return solution.first.sumOf { it.points }
    }

    private fun getBestNeighbour(
        neighbourhood: List<Triple<List<Player>, List<Player>, Player>>
    ): Triple<List<Player>, List<Player>, Player> {
        var bestNeighbour = neighbourhood.first()
        for (neighbour in neighbourhood) {
            if (fitness(Pair(neighbour.first, neighbour.second)) > fitness(
                    Pair(
                        bestNeighbour.first,
                        bestNeighbour.second
                    )
                )
            ) {
                bestNeighbour = neighbour
            }
        }
        return bestNeighbour
    }
}

class SimulatedAnnealing(
    private val constraints: Constraints,
    private val selectedTeam: Pair<List<Player>, List<Player>>,
    private val allPlayers: List<Player>,
    private var temperature: Double,
    private val coolingRate: Double
) : Algorithm {
    override fun compute(maxIter: Int, instancePath: String, instanceNumber: Number): Pair<List<Player>, List<Player>> {
        var solution = selectedTeam
        var bestSolution = selectedTeam

        var iterations = mutableListOf<Int>()
        var bestSolutionThroughTime = mutableListOf<Int>()

        while (temperature > 0.01) {
            val neighbor = generateRandomNeighbor(solution, allPlayers)

            val currentFitness = solution.first.sumOf { it.points }
            val neighborFitness = neighbor.first.sumOf { it.points }

            if (neighborFitness > currentFitness) {
                solution = neighbor
            } else {
                val probability = acceptanceProbability(currentFitness, neighborFitness, temperature)
                if (probability > Math.random()) {
                    solution = neighbor
                }
            }
            if (solution.first.sumOf { it.points } > bestSolution.first.sumOf { it.points }) {
                bestSolution = solution
            }
            temperature = decreaseTemperature(temperature, coolingRate)

            bestSolutionThroughTime.add(bestSolution.first.sumOf { it.points })
            iterations.add(iterations.size)

        }

        printChartsToFile("simulated_annealing_performance", instanceNumber, bestSolutionThroughTime, iterations)

        return bestSolution
    }

    private fun generateRandomNeighbor(
        solution: Pair<List<Player>, List<Player>>,
        allPlayers: List<Player>
    ): Pair<List<Player>, List<Player>> {
        val neighbourhood = singleSwapNeighborhood(solution.first, solution.second, allPlayers, constraints)
        return if (neighbourhood.isEmpty()) {
            solution
        } else {
            neighbourhood.random().let {
                Pair(it.first, it.second)
            }
        }
    }

    private fun acceptanceProbability(
        currentFitness: Int,
        neighborFitness: Int,
        temperature: Double
    ): Double {
        return exp(-abs(neighborFitness - currentFitness) / temperature)
    }

    private fun decreaseTemperature(temperature: Double, coolingRate: Double): Double {
        return temperature * coolingRate
    }

}