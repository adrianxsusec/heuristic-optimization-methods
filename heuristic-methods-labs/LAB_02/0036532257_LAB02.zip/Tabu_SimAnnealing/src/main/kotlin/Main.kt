import java.io.File

fun printTeam(algorithmName: String, instanceNumber: Number, firstTeam: List<Player>, subs: List<Player>) {
    println("----------------------------------------")
    println("Instance $instanceNumber $algorithmName")
    println("First team points: ${firstTeam.sumOf { it.points }}")
    println("Budget used up: ${firstTeam.sumOf { it.price } + subs.sumOf { it.price }}")
    println("First team and subs:")
    println(firstTeam.joinToString(",") { it.name })
    println(firstTeam.joinToString(",") { it.id })
    println(subs.joinToString(",") { it.id })
    println()
}

fun printTeamAndSubsToFile(algorithmName: String, instanceNumber: Number, firstTeam: List<Player>, subs: List<Player>) {
    val file = File("src/main/resources/${algorithmName}_0$instanceNumber.txt")
    file.writeText(firstTeam.joinToString(",") { it.id })
    file.appendText("\n")
    file.appendText(subs.joinToString(",") { it.id })
}

fun printChartsToFile(algorithmName: String, instanceNumber: Number, results: List<Number>, variables: List<Number>) {
    val file = File("src/main/resources/${algorithmName}_0${instanceNumber}_charts.txt")
    file.writeText(results.joinToString(","))
    file.appendText("\n")
    file.appendText(variables.joinToString(","))
}

fun main() {
    val instancePath1 = "src/main/resources/2023_Lab2_instance1.csv"
    val instancePath2 = "src/main/resources/2023_Lab2_instance2.csv"
    val (players1, clubs1) = parsePlayersAndClubs(File(instancePath1))
    val (players2, clubs2) = parsePlayersAndClubs(File(instancePath2))

    val constraints1 = Constraints(
        numPerClub = clubs1.toMutableMap(),
    )

    val constraints2 = Constraints(
        numPerClub = clubs2.toMutableMap(),
    )

    val tabuTenure = 20
    val iterations = 100

    val temperature = 10000.0
    val coolingRate = 0.95

    val (greedyFirstTeam1, greedySubs1) = Greedy(0.0, constraints1, players1).compute(1, instancePath1, 1)
    val (greedyFirstTeam2, greedySubs2) = Greedy(0.0, constraints2, players2).compute(1, instancePath2, 2)

    printTeam("Greedy", 1, greedyFirstTeam1, greedySubs1)
    printTeam("Greedy", 2, greedyFirstTeam2, greedySubs2)

    val (tabuTeam1, tabuSubs1) = TabuSearch(
        constraints1.deepCopy(),
        players1,
        Pair(greedyFirstTeam1, greedySubs1),
        tabuTenure
    ).compute(iterations, instancePath1, 1)

    val (tabuTeam2, tabuSubs2) = TabuSearch(
        constraints2.deepCopy(),
        players2,
        Pair(greedyFirstTeam2, greedySubs2),
        tabuTenure
    ).compute(iterations, instancePath2, 2)

    printTeam("Tabu", 1, tabuTeam1, tabuSubs1)
    printTeam("Tabu", 2, tabuTeam2, tabuSubs2)

    printTeamAndSubsToFile("tabu", 1, tabuTeam1, tabuSubs1)
    printTeamAndSubsToFile("tabu", 2, tabuTeam2, tabuSubs2)
//
//    val (randomTeam1, randomSubs1) = Greedy(
//        1.0,
//        constraints1.deepCopy(),
//        players1,
//    ).compute(iterations, instancePath1, 1)
//
//    val (randomTeam2, randomSubs2) = Greedy(
//        1.0,
//        constraints2.deepCopy(),
//        players2,
//    ).compute(iterations, instancePath2, 2)
//
//    val (tabuRandomTeam1, tabuRandomSubs1) = TabuSearch(
//        constraints1.deepCopy(),
//        players1,
//        Pair(randomTeam1, randomSubs1),
//        tabuTenure
//    ).compute(iterations, instancePath1, 1)
//
//    val (tabuRandomTeam2, tabuRandomSubs2) = TabuSearch(
//        constraints2.deepCopy(),
//        players2,
//        Pair(randomTeam2, randomSubs2),
//        tabuTenure
//    ).compute(iterations, instancePath2, 2)

//    printTeam("Random", 1, randomTeam1, randomSubs1)
//    printTeam("Random", 2, randomTeam2, randomSubs2)
//
//    printTeam("Tabu Random", 1, tabuRandomTeam1, tabuRandomSubs1)
//    printTeam("Tabu Random", 2, tabuRandomTeam2, tabuRandomSubs2)
//
//    printTeamAndSubsToFile("tabu_random", 1, tabuRandomTeam1, tabuRandomSubs1)
//    printTeamAndSubsToFile("tabu_random", 2, tabuRandomTeam2, tabuRandomSubs2)

    val (simulatedAnnealingTeam1, simulatedAnnealingSubs1) = SimulatedAnnealing(
        constraints1.deepCopy(),
        Pair(greedyFirstTeam1, greedySubs1),
        players1,
        temperature,
        coolingRate,
    ).compute(iterations, instancePath1, 1)

    val (simulatedAnnealingTeam2, simulatedAnnealingSubs2) = SimulatedAnnealing(
        constraints2.deepCopy(),
        Pair(greedyFirstTeam2, greedySubs2),
        players2,
        temperature,
        coolingRate,
    ).compute(iterations, instancePath2, 2)

    printTeam("Simulated Annealing", 1, simulatedAnnealingTeam1, simulatedAnnealingSubs1)
    printTeam("Simulated Annealing", 2, simulatedAnnealingTeam2, simulatedAnnealingSubs2)

    printTeamAndSubsToFile("simulated_annealing", 1, simulatedAnnealingTeam1, simulatedAnnealingSubs1)
    printTeamAndSubsToFile("simulated_annealing", 2, simulatedAnnealingTeam2, simulatedAnnealingSubs2)

//    val (simulatedAnnealingRandomTeam1, simulatedAnnealingRandomSubs1) = SimulatedAnnealing(
//        constraints1.deepCopy(),
//        Pair(randomTeam1, randomSubs1),
//        players1,
//        temperature,
//        coolingRate,
//    ).compute(iterations, instancePath1, 1)
//
//    val (simulatedAnnealingRandomTeam2, simulatedAnnealingRandomSubs2) = SimulatedAnnealing(
//        constraints2.deepCopy(),
//        Pair(randomTeam2, randomSubs2),
//        players2,
//        temperature,
//        coolingRate,
//    ).compute(iterations, instancePath2, 2)
//
//    printTeam("Simulated Annealing Random", 1, simulatedAnnealingRandomTeam1, simulatedAnnealingRandomSubs1)
//    printTeam("Simulated Annealing Random", 2, simulatedAnnealingRandomTeam2, simulatedAnnealingRandomSubs2)
//
//    printTeamAndSubsToFile("simulated_annealing_random", 1, simulatedAnnealingRandomTeam1, simulatedAnnealingRandomSubs1)
//    printTeamAndSubsToFile("simulated_annealing_random", 2, simulatedAnnealingRandomTeam2, simulatedAnnealingRandomSubs2)

    print("----------------------------------------")

}