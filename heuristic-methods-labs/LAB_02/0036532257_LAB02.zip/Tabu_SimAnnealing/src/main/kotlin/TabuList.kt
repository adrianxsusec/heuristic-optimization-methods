class TabuList<T>(private val size: Int) {
    private val tabuList = mutableListOf<T>()

    fun add(move: T) {
        tabuList.add(move)
        if (tabuList.size > size) {
            tabuList.removeAt(0)
        }
    }

    fun contains(move: T): Boolean {
        return tabuList.contains(move)
    }
}