import java.io.File

fun main() {
    val instancePath1 = "src/main/resources/2023_Lab2_instance1.csv"
    val instancePath2 = "src/main/resources/2023_Lab2_instance2.csv"
    val (players1, clubs1) = parsePlayersAndClubs(File(instancePath1))
    val (players2, clubs2) = parsePlayersAndClubs(File(instancePath2))

    val constraints1 = Constraints(
        numPerClub = clubs1.toMutableMap(),
    )

    val constraints2 = Constraints(
        numPerClub = clubs2.toMutableMap(),
    )

    val (greedyFirstTeam1, greedySubs1) = Greedy(0.0, constraints1, players1).compute(1, instancePath1, 1)
    val (greedyFirstTeam2, greedySubs2) = Greedy(0.0, constraints2, players2).compute(1, instancePath2, 2)

    val iterations = 100
    val coolingRate = 0.95

    val tabuTenures = (1..1000 step 5).toList()
    val tabuResultsInstance1 = tabuTenures.map { tabuTenure ->
        val (tabuTeam, tabuSubs) = TabuSearch(
            constraints1.deepCopy(),
            players1,
            Pair(greedyFirstTeam1, greedySubs1),
            tabuTenure
        ).compute(iterations, instancePath1, 1)
        tabuTeam.sumOf { it.points }
    }

    val tabuResultsInstance2 = tabuTenures.map { tabuTenure ->
        val (tabuTeam, tabuSubs) = TabuSearch(
            constraints2.deepCopy(),
            players2,
            Pair(greedyFirstTeam2, greedySubs2),
            tabuTenure
        ).compute(iterations, instancePath2, 2)
        tabuTeam.sumOf { it.points }
    }

    val tabuRandomResultsInstance1 = tabuTenures.map { tabuTenure ->
        val (tabuTeam, tabuSubs) = TabuSearch(
            constraints1.deepCopy(),
            players1,
            Pair(greedyFirstTeam1, greedySubs1),
            tabuTenure
        ).compute(iterations, instancePath1, 1)
        tabuTeam.sumOf { it.points }
    }

    val tabuRandomResultsInstance2 = tabuTenures.map { tabuTenure ->
        val (tabuTeam, tabuSubs) = TabuSearch(
            constraints2.deepCopy(),
            players2,
            Pair(greedyFirstTeam2, greedySubs2),
            tabuTenure
        ).compute(iterations, instancePath2, 2)
        tabuTeam.sumOf { it.points }
    }

    val simulatedAnnealingTemperatures = (1..10000 step 50).toList()
    val simulatedAnnealingResultsInstance1 = simulatedAnnealingTemperatures.map { temperature ->
        val (simulatedAnnealingTeam, simulatedAnnealingSubs) = SimulatedAnnealing(
            constraints1.deepCopy(),
            Pair(greedyFirstTeam1, greedySubs1),
            players1,
            temperature.toDouble(),
            coolingRate,
        ).compute(iterations, instancePath1, 1)
        print(simulatedAnnealingTeam.sumOf { it.points })
        simulatedAnnealingTeam.sumOf { it.points }
    }

    val simulatedAnnealingResultsInstance2 = simulatedAnnealingTemperatures.map { temperature ->
        val (simulatedAnnealingTeam, simulatedAnnealingSubs) = SimulatedAnnealing(
            constraints2.deepCopy(),
            Pair(greedyFirstTeam2, greedySubs2),
            players2,
            temperature.toDouble(),
            coolingRate,
        ).compute(iterations, instancePath2, 2)
        print(simulatedAnnealingTeam.sumOf { it.points })
        simulatedAnnealingTeam.sumOf { it.points }
    }

    val simulatedAnnealingRandomResultsInstance1 = simulatedAnnealingTemperatures.map { temperature ->
        val (simulatedAnnealingTeam, simulatedAnnealingSubs) = SimulatedAnnealing(
            constraints1.deepCopy(),
            Pair(greedyFirstTeam1, greedySubs1),
            players1,
            temperature.toDouble(),
            coolingRate,
        ).compute(iterations, instancePath1, 1)
        print(simulatedAnnealingTeam.sumOf { it.points })
        simulatedAnnealingTeam.sumOf { it.points }
    }

    val simulatedAnnealingRandomResultsInstance2 = simulatedAnnealingTemperatures.map { temperature ->
        val (simulatedAnnealingTeam, simulatedAnnealingSubs) = SimulatedAnnealing(
            constraints2.deepCopy(),
            Pair(greedyFirstTeam2, greedySubs2),
            players2,
            temperature.toDouble(),
            coolingRate,
        ).compute(iterations, instancePath2, 2)
        print(simulatedAnnealingTeam.sumOf { it.points })
        simulatedAnnealingTeam.sumOf { it.points }
    }

    printChartsToFile("tabu", 1, tabuResultsInstance1, tabuTenures)
    printChartsToFile("tabu", 2, tabuResultsInstance2, tabuTenures)
    printChartsToFile("simulated_annealing", 1, simulatedAnnealingResultsInstance1, simulatedAnnealingTemperatures)
    printChartsToFile("simulated_annealing", 2, simulatedAnnealingResultsInstance2, simulatedAnnealingTemperatures)

    printChartsToFile("tabu_random", 1, tabuRandomResultsInstance1, tabuTenures)
    printChartsToFile("tabu_random", 2, tabuRandomResultsInstance2, tabuTenures)
    printChartsToFile("simulated_annealing_random", 1, simulatedAnnealingRandomResultsInstance1, simulatedAnnealingTemperatures)
    printChartsToFile("simulated_annealing_random", 2, simulatedAnnealingRandomResultsInstance2, simulatedAnnealingTemperatures)

}